(function () {
    fetch('https://www.aui2.cn/host/status.json')
        .then(function (response) {
            return response.json();
        })
        .then(function (res) {
            var list = res.content.website;
            var updateTime = res.content.updateTime;
            var html = `<div class="presentation-ctn">
            <div class=" max-screen-width">
                <h2 class="main-title">演示列表 <span>presentation</span></h2>
                <ul class="presentation-list">
                    ${list.sort((a,b)=>{
                        return parseInt(a.seq,10)-parseInt(b.seq,10);
                    }).map(e=>`<li>
                        <a href="${e.path}" target="_blank" alt="${e.desp}">
                            <div>
                                <span class="dot ${e.status?'dot-normal':'dot-error'}"></span>
                                <svg class="icon" aria-hidden="true">
                                    <use xlink:href="#${e.icon}"></use>
                                </svg>
                            </div>
                            <div>
                                <p>${e.desp}</p>
                            </div>
                        </a>
                    </li>`).join('')}
                </ul>
            </div>
        </div>`;
            document.getElementById('presentation').innerHTML = html;
        }).catch(e => {
            debugger;
        });
    fetch('./data/data.json')
        .then(function (r) {
            return r.json();
        })
        .then(function (res) {
            var menu = res && res.menu;

            if (menu && menu.length) {
                document.getElementById('content').innerHTML += menu.map(function (menu) {
                    return res[menu.id] && res[menu.id].length ? `
                            <div class="product-ctn" id="${menu.id}">
                                <div class=" max-screen-width">
                                    <h2 class="main-title">${menu.name}&nbsp;<span>${menu.id}</span></h2>
                                    <ul class="product-list">
                                        ${res[menu.id].map(function (item) {
                        return `<li>
                                                        <div class="product">
                                                            <div class="product-img-ctn">
                                                                <img src="${item.img}" alt="${item.name}" title="${item.title}"/>
                                                            </div>
                                                            <div  class="product-content">
                                                                <sub class="product-date">${item.date}</sub>
                                                                <h3 class="product-title">${item.name} <sup class="product-version">${item.version}</sup></h3>
                                                                <p class="product-details">${item.details}</p>
                                                                ${item.links && item.links.length ? `<ul class="product-link-list">${item.links.map(function (link) {
                            return `<li><a href="${link.href}" target="_blank">${link.name}</a></li>`;
                        }).join('')}</ul>` : ''}
                                                            </div>
                                                        </div>
                                                    </li>`;
                    }).join('')}
                                    </ul>
                                </div>
                            </div>`: '';
                }).join('');
            }
        })
        .catch(function (e) {
            console.log(e);
            debugger;
        })
}());